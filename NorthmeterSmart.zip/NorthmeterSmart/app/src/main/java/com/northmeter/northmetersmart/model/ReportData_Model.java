package com.northmeter.northmetersmart.model;

/**消息报警和记录*/
public class ReportData_Model {
	public String id;
	public String time;
	public String reportData;
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getReportData() {
		return reportData;
	}
	public void setReportData(String reportData) {
		this.reportData = reportData;
	}

	
	

}

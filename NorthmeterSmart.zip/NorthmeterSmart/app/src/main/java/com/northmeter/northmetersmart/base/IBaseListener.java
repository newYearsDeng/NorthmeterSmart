package com.northmeter.northmetersmart.base;

/**
 * Created by dyd on 2018/12/5.
 */

public interface IBaseListener {

    void startView();
    void initData();
    void initView();
}

package com.northmeter.northmetersmart.db;

public class DBStrings {
	public static final String DBName = "BCSmart.db";
	public static final Integer DBVersion = 19;
}

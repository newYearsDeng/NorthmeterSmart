package com.northmeter.northmetersmart.wxpay;

public class Constants {


    //appid 微信分配的公众账号ID
	public static final String APP_ID = "wx9c9b6d5e89202be0";

  	//商户号 微信分配的公众账号ID
    public static final String MCH_ID = "1458320802";

   	//API密钥，在商户平台设置
    public static final  String API_KEY= "1ABBE470BEB588033771A7743600B03B";
      
	public static final String WX_secret = "8dc9de64251271aed3ea44e8a6793ec8";
	
	
	//mob短信认证
	public static final String MOB_APP_KEY = "1b4769ff38434";
	public static final String MOB_secret = "84e9c3d6c4d4213d832b36e8f1eae458";


}

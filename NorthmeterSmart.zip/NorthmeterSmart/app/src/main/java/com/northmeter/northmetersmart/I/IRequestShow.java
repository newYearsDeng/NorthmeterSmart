package com.northmeter.northmetersmart.I;

public interface IRequestShow {

	public void requestShow(String msg);
	
}

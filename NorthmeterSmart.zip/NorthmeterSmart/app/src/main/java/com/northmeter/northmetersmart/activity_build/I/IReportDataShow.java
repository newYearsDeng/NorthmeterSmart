package com.northmeter.northmetersmart.activity_build.I;


import com.northmeter.northmetersmart.model.ReportData_Model;

public interface IReportDataShow {

	void showReportData(ReportData_Model model);
}

package com.northmeter.northmetersmart.activity_build.I;

public interface IRoomDeviceShow {

	void showRoomDevice(String data);
}

package com.northmeter.northmetersmart.I;

public interface ILightDevieShow {

	public void showLightDevice(int xRefreshType, String data);
}

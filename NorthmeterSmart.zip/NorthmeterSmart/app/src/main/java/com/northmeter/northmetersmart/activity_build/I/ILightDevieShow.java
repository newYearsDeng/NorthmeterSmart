package com.northmeter.northmetersmart.activity_build.I;

public interface ILightDevieShow {

	public void showLightDevice(int xRefreshType, String data);
}

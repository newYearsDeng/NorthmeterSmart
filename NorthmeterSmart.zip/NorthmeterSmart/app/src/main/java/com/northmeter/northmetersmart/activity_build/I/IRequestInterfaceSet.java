package com.northmeter.northmetersmart.activity_build.I;

public interface IRequestInterfaceSet {
	public void getHttpRequestPostSet_Cookie(String url, String para, String cookie);
}

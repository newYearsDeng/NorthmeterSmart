package com.northmeter.northmetersmart.activity_build.I;

public interface IRequestSet {

	public void showRequestSet(String result);
}

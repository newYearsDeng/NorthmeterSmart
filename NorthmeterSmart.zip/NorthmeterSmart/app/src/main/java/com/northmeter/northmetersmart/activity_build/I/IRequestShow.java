package com.northmeter.northmetersmart.activity_build.I;

public interface IRequestShow {

	public void requestShow(String msg);
	
}

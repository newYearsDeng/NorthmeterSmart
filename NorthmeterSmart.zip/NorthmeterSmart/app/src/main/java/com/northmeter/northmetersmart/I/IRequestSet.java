package com.northmeter.northmetersmart.I;

public interface IRequestSet {

	public void showRequestSet(String result);
}

package com.northmeter.northmetersmart.wxPresenter;

public interface I_WXRequestShow {

	public void showWXRequestData(int what, String msg);
}

package com.northmeter.northmetersmart.I;

public interface IRequestInterfaceSet {
	public void getHttpRequestPostSet_Cookie(String url, String para, String cookie);
}

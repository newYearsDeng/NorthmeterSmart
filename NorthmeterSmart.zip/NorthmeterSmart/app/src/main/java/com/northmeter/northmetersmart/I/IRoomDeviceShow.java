package com.northmeter.northmetersmart.I;

public interface IRoomDeviceShow {

	void showRoomDevice(String data);
}

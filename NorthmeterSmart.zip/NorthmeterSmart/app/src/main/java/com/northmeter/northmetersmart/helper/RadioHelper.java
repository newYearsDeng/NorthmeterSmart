package com.northmeter.northmetersmart.helper;

import android.widget.RadioGroup;

public class RadioHelper {
	public static RadioGroup radioGroup;
}
